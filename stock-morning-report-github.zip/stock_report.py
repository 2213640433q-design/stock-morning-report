#!/usr/bin/env python3
"""
股票晨报 - GitHub Actions 版本
"""

import json
import urllib.request
import os
from datetime import datetime
import ssl

# 自选股列表
WATCHLIST = [
    {"code": "600111", "name": "北方稀土"},
]

def get_stock_quote(code):
    """获取股票行情"""
    if code.startswith(('6', '5', '9')):
        market = "sh"
    elif code.startswith(('0', '3', '2')):
        market = "sz"
    elif code.startswith(('43', '83', '87')):
        market = "bj"
    else:
        market = "sh"
    
    url = f"https://qt.gtimg.cn/q={market}{code}"
    
    try:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=10, context=ctx) as response:
            data = response.read().decode('gbk', errors='ignore')
            
            prefix = f'v_{market}{code}="'
            if prefix in data:
                start = data.find(prefix) + len(prefix)
                end = data.find('"', start)
                content = data[start:end]
                fields = content.split('~')
                
                if len(fields) >= 35:
                    price = float(fields[3])
                    prev_close = float(fields[4])
                    change = round(price - prev_close, 2)
                    change_pct = round(change / prev_close * 100, 2)
                    
                    # 更新时间格式化
                    update_time = fields[30] if len(fields) > 30 else ""
                    if len(update_time) == 14:
                        formatted_time = f"{update_time[:4]}-{update_time[4:6]}-{update_time[6:8]} {update_time[8:10]}:{update_time[10:12]}"
                    else:
                        formatted_time = "N/A"
                    
                    return {
                        "code": code,
                        "name": fields[1],
                        "price": price,
                        "prev_close": prev_close,
                        "change": change,
                        "change_pct": change_pct,
                        "open": float(fields[5]),
                        "high": float(fields[33]),
                        "low": float(fields[34]),
                        "volume": fields[6],
                        "update_time": formatted_time
                    }
    except Exception as e:
        print(f"Error fetching {code}: {e}")
        return {"code": code, "name": "未知", "error": str(e)}
    
    return {"code": code, "name": "未知", "error": "无数据"}

def generate_ai_analysis(stock):
    """生成AI分析文本（简化版）"""
    code = stock["code"]
    name = stock["name"]
    change_pct = stock.get("change_pct", 0)
    
    # 基于涨跌的简单分析（实际应由LLM完成）
    if change_pct > 5:
        trend = "强势上涨"
        impact = "短期情绪积极，需关注成交量是否配合"
        valuation = "估值有所修复，但仍需观察持续性"
    elif change_pct > 0:
        trend = "小幅上涨"
        impact = "市场情绪平稳，关注是否有利好消息"
        valuation = "估值相对稳定"
    elif change_pct > -5:
        trend = "小幅回调"
        impact = "短期调整，关注支撑位是否有效"
        valuation = "估值有所压缩，或存机会"
    else:
        trend = "大幅下跌"
        impact = "短期承压，需关注是否有利空消息"
        valuation = "估值明显回落，谨慎观望"
    
    return {
        "trend": trend,
        "impact": impact,
        "valuation": valuation
    }

def build_feishu_card(quotes):
    """构建飞书卡片消息"""
    today = datetime.now().strftime("%Y年%m月%d日")
    
    header = {
        "template": "blue",
        "title": {
            "tag": "plain_text",
            "content": f"📊 股票晨报 - {today}"
        }
    }
    
    elements = []
    
    for quote in quotes:
        if "error" in quote:
            continue
            
        name = quote["name"]
        code = quote["code"]
        price = quote["price"]
        change = quote["change"]
        change_pct = quote["change_pct"]
        update_time = quote.get("update_time", "N/A")
        
        # 涨跌颜色
        color = "green" if change >= 0 else "red"
        emoji = "📈" if change >= 0 else "📉"
        
        # AI 分析
        analysis = generate_ai_analysis(quote)
        
        # 股票标题
        elements.append({
            "tag": "div",
            "text": {
                "tag": "lark_md",
                "content": f"**{emoji} {name} ({code})**"
            }
        })
        
        # 价格信息
        elements.append({
            "tag": "div",
            "text": {
                "tag": "lark_md",
                "content": f"现价: **¥{price}** | 涨跌: **{change:+.2f} ({change_pct:+.2f}%)** | 时间: {update_time}"
            }
        })
        
        # 分析
        elements.append({
            "tag": "div",
            "text": {
                "tag": "lark_md",
                "content": f"💡 **趋势**: {analysis['trend']}\n📰 **影响**: {analysis['impact']}\n💰 **估值**: {analysis['valuation']}"
            }
        })
        
        # 分隔线
        elements.append({"tag": "hr"})
    
    # 底部说明
    elements.append({
        "tag": "div",
        "text": {
            "tag": "lark_md",
            "content": "*数据来源: 腾讯财经 | 分析仅供参考，不构成投资建议*"
        }
    })
    
    return {
        "config": {"wide_screen_mode": True},
        "header": header,
        "elements": elements
    }

def send_to_feishu(card):
    """发送到飞书"""
    webhook_url = os.environ.get('FEISHU_WEBHOOK_URL', '')
    
    if not webhook_url:
        print("错误: 未设置 FEISHU_WEBHOOK_URL")
        print("请在 GitHub Secrets 中添加 FEISHU_WEBHOOK_URL")
        return False
    
    payload = {
        "msg_type": "interactive",
        "card": card
    }
    
    try:
        data = json.dumps(payload).encode('utf-8')
        req = urllib.request.Request(
            webhook_url,
            data=data,
            headers={'Content-Type': 'application/json'},
            method='POST'
        )
        
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        
        with urllib.request.urlopen(req, timeout=10, context=ctx) as response:
            result = json.loads(response.read().decode('utf-8'))
            if result.get('code') == 0:
                print("✅ 飞书消息发送成功")
                return True
            else:
                print(f"❌ 发送失败: {result}")
                return False
    except Exception as e:
        print(f"❌ 发送错误: {e}")
        return False

def main():
    print("=" * 50)
    print("📊 股票晨报生成器")
    print("=" * 50)
    
    # 获取行情
    print("\n1. 获取自选股行情...")
    quotes = []
    for stock in WATCHLIST:
        print(f"   获取 {stock['name']} ({stock['code']})...")
        quote = get_stock_quote(stock['code'])
        quotes.append(quote)
        print(f"   ✅ {quote.get('name', 'N/A')}: ¥{quote.get('price', 'N/A')}")
    
    # 生成卡片
    print("\n2. 生成飞书卡片...")
    card = build_feishu_card(quotes)
    
    # 发送
    print("\n3. 推送到飞书...")
    success = send_to_feishu(card)
    
    # 保存报告（用于调试）
    report = {
        "date": datetime.now().isoformat(),
        "quotes": quotes
    }
    with open('report.json', 'w', encoding='utf-8') as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    
    print("\n4. 报告已保存到 report.json")
    
    if success:
        print("\n✅ 股票晨报推送完成！")
    else:
        print("\n❌ 推送失败，请检查配置")
        exit(1)

if __name__ == "__main__":
    main()
